# Deploy to GitHub Pages → gateoaks.net

No coding or command line needed — everything happens in your browser.

## Part 1 — Put the site on GitHub (≈10 min)

1. Create a free account at **github.com** (or log in).
2. Click the **+** (top right) → **New repository**:
   - Name: `gateoaks`
   - **Public** (required for free Pages hosting)
   - Click **Create repository**
3. On the empty repo page, click **"uploading an existing file"**.
4. Drag in **everything inside the `gateoaks` folder** from this workspace:
   - `index.html`
   - the `images/` folder (drag the whole folder in — needed for link previews)
   - `robots.txt`, `sitemap.xml`, `CNAME` (CNAME is important — it's pre-made with gateoaks.net)
   - `GO-LIVE.md` / `GITHUB-PAGES.md` (optional, harmless)
5. Click **Commit changes**.

## Part 2 — Turn on GitHub Pages (≈2 min)

6. Repo → **Settings** → **Pages** (left sidebar).
7. **Source: Deploy from a branch** → Branch: `main` → folder: `/(root)` → **Save**.
8. Wait 1–2 minutes, refresh — your site appears at `https://<your-username>.github.io/gateoaks`.
   Test that everything works there (images, map, Oak the chatbot).

## Part 3 — Point gateoaks.net at it (≈10 min + waiting)

9. Still in **Settings → Pages**: **Custom domain** → type `gateoaks.net` → **Save**.
10. Log into your domain account at **domains.squarespace.com** (Google Domains migrated there)
    → **gateoaks.net** → **DNS settings**. Delete any existing A or CNAME records for `@` and `www`, then add:

    **Four A records** (host `@` = the bare domain):

    | Type | Host | Value |
    |---|---|---|
    | A | @ | `185.199.108.153` |
    | A | @ | `185.199.109.153` |
    | A | @ | `185.199.110.153` |
    | A | @ | `185.199.111.153` |

    **One CNAME record** (for www):

    | Type | Host | Value |
    |---|---|---|
    | CNAME | www | `<your-username>.github.io` |

11. Wait **5 min – 24 hrs** for DNS to propagate. Then back in repo **Settings → Pages**:
    check ✅ **Enforce HTTPS** (only after the DNS check passes and the certificate is issued).

Done — **https://gateoaks.net** serves your site. Clean URL, free hosting, free SSL.

## Notes

- The `CNAME` file in this folder already contains `gateoaks.net`, so even if you
  re-upload files later, your domain setting won't get wiped.
- GitHub Pages free tier: public repos only (fine — it's a public brochure site).
- If you can't access the old Squarespace/Google domain account: contact Squarespace
  Domains support with proof of ownership, or register the backup **gateoaks.co**
  (~$11/yr) and use it everywhere this guide says `gateoaks.net` (also update the
  CNAME file and the canonical URLs in `index.html`).

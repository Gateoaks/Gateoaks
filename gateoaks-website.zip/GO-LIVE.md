# Go Live: gateoaks.net

Everything in this folder is production-ready and pre-configured for **gateoaks.net**
(canonical URLs, Open Graph tags, sitemap, robots.txt).

## Good news: you almost certainly already own gateoaks.net

Registrar records (checked 2026-07-15):

| Domain | Status | Notes |
|---|---|---|
| **gateoaks.net** | Registered until **Jun 2027** | Google Domains (now Squarespace Domains) — same owner as the rest below |
| gateoaks.com | Registered until Jun 2027 | Points to Wix DNS (probably your old site) |
| gateoaksapts.com / gateoaksapartments.com | Registered until Jun 2027 | Same registration day — same owner |
| gateoaks.co | **Available** | ~$11/yr backup if needed |

Since all four domains were registered the same day (June 16, 2019) — gateoaks.com even points to Wix, where the Gate Oaks photos are hosted — they're almost certainly in **your Squarespace Domains account** (Google Domains migrated there). Log in at **domains.squarespace.com** (or squarespace.com/login) with the Google account used in 2019.

---

## Step 1 — Put the site on free hosting (5 min, no cost)

Pick ONE:

**Option A — Netlify (easiest, drag & drop)**
1. Go to app.netlify.com → sign up free
2. Drag this entire `gateoaks` folder onto the dashboard
3. You'll get a temporary URL like `random-name.netlify.app`

**Option B — Cloudflare Pages (also free, very fast)**
1. dash.cloudflare.com → sign up → Workers & Pages → Create → Pages → "Upload assets"
2. Upload the `gateoaks` folder → Deploy

**Option C — Vercel**
1. vercel.com → sign up → "Add New → Project" → upload the folder

## Step 2 — Point gateoaks.net at the host (10 min)

1. In your host's dashboard: **Add custom domain** → enter `gateoaks.net` (and `www.gateoaks.net`).
   The host will show you the exact records to create — typically:
   - `A` record for `gateoaks.net` → their IP (or an `ANAME`/`ALIAS`/`CNAME` they give you)
   - `CNAME` for `www` → your project URL
2. Log into **domains.squarespace.com** → gateoaks.net → DNS settings
   - Delete/replace the old parked records with the records from Step 2.1
3. Wait 5–60 minutes for DNS to propagate. HTTPS is issued automatically by the host.

Done — **https://gateoaks.net** is live, clean URL, no weird parameters.

> Netlify tip: they also offer "Netlify DNS" — you can instead change the nameservers at
> Squarespace to Netlify's 4 nameservers and skip manual records.

---

## The AI assistant ("Oak")

Already built into `index.html` — bottom-right chat bubble. It answers questions about
rent, availability, pets, tours, hours, maintenance, neighborhood, and more using an
on-device knowledge engine. It works with **no server and no API key**.

**Optional upgrade — true generative AI:** set this before the Oak script tag in `index.html`:
```html
<script>window.GATEOAKS_AI_ENDPOINT = "https://your-api.example.com/chat";</script>
```
The widget will POST `{ "message": "..." }` there and render the `{ "reply": "..." }`
response, automatically falling back to the local engine on error. Point it at any
backend you control (a small Cloudflare/Vercel function wrapping an LLM API works well).
Keep your LLM API key on the server side — never in this file.

## Files

```
gateoaks/
├── index.html      ← the whole website — FULLY self-contained
│                     (fonts + CSS + JS + all 12 photos embedded)
├── images/         ← still upload this folder: the social-share card (og:image)
│                     and sitemap reference gateoaks.net/images/hero-building.jpg
├── robots.txt
└── sitemap.xml
```

You can share/deploy just `index.html` by itself and every image will load —
the `images/` folder is only needed on the live domain for link previews
(e.g. when someone texts the gateoaks.net link).
